const juiceHost = process.env.JUICE_HOST || 'development.limecraft.com';
const juicePort = process.env.JUICE_PORT || 443;
const juiceProtocol = process.env.JUICE_PROTOCOL || 'https';

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // Avoids DEPTH_ZERO_SELF_SIGNED_CERT error for self-signed certs

const config = {
    juice: {
        connection: {
            url: `${juiceProtocol}://${juiceHost}/api`,
            host: juiceHost,
            port: juicePort,
            protocol: juiceProtocol,
            path: 'api',
        },
    },
    logger: {
        level: 'info',
        options: {
            console: true,
            file: false,
            flow: false,
        },
    },
    user: process.env.JUICE_USER || 'wim',
    password: process.env.JUICE_PASSWORD || 'test1234',
    language: process.env.TRANSCRIPT_LANGUAGE,
    throttleUpload: -1, // desired max bytes per second
};

module.exports = config;

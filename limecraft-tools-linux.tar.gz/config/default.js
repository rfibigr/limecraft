const juiceHost = process.env.JUICE_HOST || 'platform.limecraft.com';
const juicePort = process.env.JUICE_PORT || 443;
const juiceProtocol = process.env.JUICE_PROTOCOL || 'https';

const config = {
    juice: {
        connection: {
            url: `${juiceProtocol}://${juiceHost}/api`,
            host: juiceHost,
            port: juicePort,
            protocol: juiceProtocol,
            path: 'api',
        },
    },
    logger: {
        level: 'info',
        options: {
            console: {
                options: {
                    stderrLevels: ['info', 'error', 'warn', 'debug'],
                },
            },
            file: {
                logPath: process.env.LOG_PATH,
            },
            flow: {
                host: `${juiceProtocol}://${juiceHost}/api`,
                token: process.env.LOGGER_TOKEN || '65017ee4-e0cc-4f8e-ab27-36760fb27aa0',
            },
        },
    },
    user: process.env.JUICE_USER,
    password: process.env.JUICE_PASSWORD,
    production: process.env.JUICE_PRODUCTION,
    language: process.env.TRANSCRIPT_LANGUAGE,
    throttleUpload: -1, // desired max bytes per second
};

module.exports = config;
